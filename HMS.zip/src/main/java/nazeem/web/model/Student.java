package nazeem.web.model;

import javax.persistence.*;

@Entity
@Table(name="student")
public class Student {

    protected Student() {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "student_id")
    private Long id;


    public Long getId() {
        return id;
    }
    public void setId(Long id){
        this.id=id;
    }

    @Column(name = "name")
    private String name;

    public String getName(){
        return this.name;
    }
    public void setName(String name){
        this.name=name;
    }

    @Column(name = "hostel_id")
    private long hostel_id;

    public long getHostel_id(){
        return this.hostel_id;
    }
    public void setHostel_id(long hostel_id){
        this.hostel_id=hostel_id;
    }

    @Column(name = "room_id")
    private long room_id;

    public long getRoom_id(){
        return this.room_id;
    }
    public void setRoom_id(long room_id){
        this.room_id=room_id;
    }




    // other getters and setters are hidden for brevity
}